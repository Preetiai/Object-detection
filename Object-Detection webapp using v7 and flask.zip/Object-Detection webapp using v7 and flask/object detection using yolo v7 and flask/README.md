# Object-Detection-Web-App-Using-YOLOv7-and-Flask
Object Detection Web App Using YOLOv7 and Flask

Steps to use:

1- Setup the environment to run yolov7 and flask.

2- Clone this github repo.

3- Paste your custom model in the cloned repo.

4- Run :  python webapp.py

5



